﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MMAProducts.models.datalayer;

namespace MMAProducts
{
    public partial class frmAddModify : Form
    {

        public frmAddModify()
        {
            InitializeComponent();
        }


        public Product? product { get; set; }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            //send cancel dialog back to the calling form
            this.DialogResult = DialogResult.Cancel;
        }

        private void setTechnicianObj()
        {
            product = new Product();

            product.ProductCode = txtProductCode.Text;
            product.Description = txtDesc.Text;
            product.UnitPrice = Convert.ToDecimal(txtUnitPrice.Text);
            product.OnHandQuantity = Convert.ToInt32(txtOnHand.Text);
        }

        private bool isValid()
        {

            int errorCount = 0;
            string errorMsg = "";
            decimal decUnitPrice = -1;
            int intOnHand = -1;

            if (txtProductCode.Text.Length <= 0)
            {
                errorCount++;
                errorMsg += "Product code must not be empty \n";
            }
            if (txtDesc.Text.Length <= 0)
            {
                errorCount++;
                errorMsg += "Description must not be empty \n";
            }

            if (txtUnitPrice.Text.Length <= 0)
            {
                errorCount++;
                errorMsg += "Unit price must not be empty \n";
            }
            if (!decimal.TryParse(txtUnitPrice.Text, out _))
            {
                errorCount++;
                errorMsg += "Unit price format must be a valid number (decimal)\n";
            }
            else
            {
                decUnitPrice = decimal.Parse(txtUnitPrice.Text);
            }
            if (decUnitPrice <= 0)
            {
                errorCount++;
                errorMsg += "Unit price must be greater than zero\n";
            }


            if (txtOnHand.Text.Length <= 0)
            {
                errorCount++;
                errorMsg += "On hand quantity must not be empty \n";
            }
            if (!int.TryParse(txtOnHand.Text, out _))
            {
                errorCount++;
                errorMsg += "On hand quantity must be a valid number (int) \n";
            }
            else
            {
                intOnHand = int.Parse(txtOnHand.Text);
            }
            if (intOnHand < 0)
            {
                errorCount++;
                errorMsg += "On hand quantity must be greater than or equal to zero\n";
            }





            if (errorCount > 0)
            {
                MessageBox.Show(errorMsg);
                return false;
            }
            else
            {
                return true;
            }
        }

        private void btnAccept_Click(object sender, EventArgs e)
        {
            if (isValid())
            {
                setTechnicianObj();
                this.DialogResult = DialogResult.OK;
            }
        }

        private void frmAddModify_Load(object sender, EventArgs e)
        {
            this.Text = "Add Product";
        }
    }
}
