﻿namespace MMAProducts
{
    partial class frmAddModify
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnCancel = new Button();
            btnAccept = new Button();
            txtProductCode = new TextBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            txtDesc = new TextBox();
            txtUnitPrice = new TextBox();
            txtOnHand = new TextBox();
            SuspendLayout();
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(521, 382);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(184, 117);
            btnCancel.TabIndex = 21;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnAccept
            // 
            btnAccept.Location = new Point(160, 382);
            btnAccept.Name = "btnAccept";
            btnAccept.Size = new Size(184, 117);
            btnAccept.TabIndex = 20;
            btnAccept.Text = "Accept";
            btnAccept.UseVisualStyleBackColor = true;
            btnAccept.Click += btnAccept_Click;
            // 
            // txtProductCode
            // 
            txtProductCode.Location = new Point(251, 75);
            txtProductCode.Name = "txtProductCode";
            txtProductCode.Size = new Size(200, 39);
            txtProductCode.TabIndex = 15;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(21, 287);
            label4.Name = "label4";
            label4.Size = new Size(210, 32);
            label4.TabIndex = 14;
            label4.Text = "Quantity on Hand:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(110, 213);
            label3.Name = "label3";
            label3.Size = new Size(121, 32);
            label3.TabIndex = 13;
            label3.Text = "Unit Price:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(91, 146);
            label2.Name = "label2";
            label2.Size = new Size(140, 32);
            label2.TabIndex = 12;
            label2.Text = "Description:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(67, 78);
            label1.Name = "label1";
            label1.Size = new Size(164, 32);
            label1.TabIndex = 11;
            label1.Text = "Product Code:";
            // 
            // txtDesc
            // 
            txtDesc.Location = new Point(251, 146);
            txtDesc.Name = "txtDesc";
            txtDesc.Size = new Size(671, 39);
            txtDesc.TabIndex = 22;
            // 
            // txtUnitPrice
            // 
            txtUnitPrice.Location = new Point(251, 213);
            txtUnitPrice.Name = "txtUnitPrice";
            txtUnitPrice.Size = new Size(200, 39);
            txtUnitPrice.TabIndex = 23;
            // 
            // txtOnHand
            // 
            txtOnHand.Location = new Point(251, 284);
            txtOnHand.Name = "txtOnHand";
            txtOnHand.Size = new Size(200, 39);
            txtOnHand.TabIndex = 24;
            // 
            // frmAddModify
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(954, 571);
            Controls.Add(txtOnHand);
            Controls.Add(txtUnitPrice);
            Controls.Add(txtDesc);
            Controls.Add(btnCancel);
            Controls.Add(btnAccept);
            Controls.Add(txtProductCode);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "frmAddModify";
            Text = "Add/Modify Product";
            Load += frmAddModify_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnCancel;
        private Button btnAccept;
        private TextBox txtProductCode;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtDesc;
        private TextBox txtUnitPrice;
        private TextBox txtOnHand;
    }
}