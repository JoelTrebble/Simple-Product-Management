using Microsoft.EntityFrameworkCore;
using MMAProducts.models.datalayer;
using System.Windows.Forms;
namespace MMAProducts
{
    public partial class Form1 : Form
    {
        private MMAProductsContext context = new MMAProductsContext(); //this line adds the using automatically
        private Product? product;


        public Form1()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void displayProduct()
        {
            if (product != null)
            {
                txtProductCode.Text = product.ProductCode.ToString();
                lblDesc.Text = product.Description.ToString();
                lblUnitPrice.Text = product.UnitPrice.ToString("c");
                lblOnHand.Text = product.OnHandQuantity.ToString();
            }

        }

        private void btnGetProduct_Click(object sender, EventArgs e)
        {
            string prodID = txtProductCode.Text;

            if (prodID != null)
            {
                //call on the context object to return a customer
                try
                {
                    product = context.Products.Find(prodID);
                    if (product != null)
                    {

                        displayProduct();

                    }
                    else
                    {
                        MessageBox.Show("Product not found");
                        txtProductCode.Text = string.Empty;
                        lblDesc.Text = string.Empty;
                        lblUnitPrice.Text = string.Empty;
                        lblOnHand.Text = string.Empty;
                        txtProductCode.Focus();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Please enter in a valid product code.");
                txtProductCode.Text = string.Empty;
                txtProductCode.Focus();

            }

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            frmAddModify f = new frmAddModify();
            DialogResult result = f.ShowDialog();
            if (result == DialogResult.OK)
            {
                try
                {
                    product = f.product;
                    context.Products.Add(product);
                    context.SaveChanges();
                    displayProduct();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }
}
