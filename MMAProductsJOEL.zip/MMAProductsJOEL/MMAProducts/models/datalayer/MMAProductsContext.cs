﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using System.Configuration; //must add this using manually
using MySql.EntityFrameworkCore.Extensions; // Add this for MySQL support

namespace MMAProducts.models.datalayer;

public partial class MMAProductsContext : DbContext
{
    public MMAProductsContext()
    {
    }

    public MMAProductsContext(DbContextOptions<MMAProductsContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Customer> Customers { get; set; }

    public virtual DbSet<Invoice> Invoices { get; set; }

    public virtual DbSet<InvoiceLineItem> InvoiceLineItems { get; set; }

    public virtual DbSet<OrderOption> OrderOptions { get; set; }

    public virtual DbSet<Product> Products { get; set; }

    public virtual DbSet<State> States { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
      => optionsBuilder.UseMySQL(ConfigurationManager.ConnectionStrings["MMAProducts"].ConnectionString);
    

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Customer>(entity =>
        {
            entity.Property(e => e.CustomerId).HasColumnName("CustomerID");
            entity.Property(e => e.Address)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.City)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.State)
                .HasMaxLength(2)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.ZipCode)
                .HasMaxLength(15)
                .IsUnicode(false)
                .IsFixedLength();

            entity.HasOne(d => d.StateNavigation).WithMany(p => p.Customers)
                .HasForeignKey(d => d.State)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Customers_States");
        });

        modelBuilder.Entity<Invoice>(entity =>
        {
            entity.Property(e => e.InvoiceId).HasColumnName("InvoiceID");
            entity.Property(e => e.CustomerId).HasColumnName("CustomerID");
            entity.Property(e => e.InvoiceDate).HasColumnType("datetime");
            entity.Property(e => e.InvoiceTotal).HasPrecision(10, 2); // Changed for MySQL
            entity.Property(e => e.ProductTotal).HasPrecision(10, 2); // Changed for MySQL
            entity.Property(e => e.SalesTax).HasPrecision(10, 2);     // Changed for MySQL
            entity.Property(e => e.Shipping).HasPrecision(10, 2);     // Changed for MySQL

            entity.HasOne(d => d.Customer).WithMany(p => p.Invoices)
                .HasForeignKey(d => d.CustomerId)
                .HasConstraintName("FK_Invoices_Customers");
        });

        modelBuilder.Entity<InvoiceLineItem>(entity =>
        {
            entity.HasKey(e => new { e.InvoiceId, e.ProductCode });

            entity.Property(e => e.InvoiceId).HasColumnName("InvoiceID");
            entity.Property(e => e.ProductCode)
                .HasMaxLength(10)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.ItemTotal).HasPrecision(10, 2);   // Changed for MySQL
            entity.Property(e => e.UnitPrice).HasPrecision(10, 2);   // Changed for MySQL

            entity.HasOne(d => d.Invoice).WithMany(p => p.InvoiceLineItems)
                .HasForeignKey(d => d.InvoiceId)
                .HasConstraintName("FK_InvoiceLineItems_Invoices");

            entity.HasOne(d => d.ProductCodeNavigation).WithMany(p => p.InvoiceLineItems)
                .HasForeignKey(d => d.ProductCode)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_InvoiceLineItems_Products");
        });

        modelBuilder.Entity<OrderOption>(entity =>
        {
            entity.HasKey(e => e.OptionId);

            entity.Property(e => e.OptionId).HasColumnName("OptionID");
            entity.Property(e => e.AdditionalBookShipCharge).HasPrecision(10, 2);  // Changed for MySQL
            entity.Property(e => e.FirstBookShipCharge).HasPrecision(10, 2);       // Changed for MySQL
            entity.Property(e => e.SalesTaxRate).HasPrecision(18, 4);              // Changed for MySQL
        });

        modelBuilder.Entity<Product>(entity =>
        {
            entity.HasKey(e => e.ProductCode);

            entity.Property(e => e.ProductCode)
                .HasMaxLength(10)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.Description)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UnitPrice).HasPrecision(10, 2);  // Changed for MySQL
        });

        modelBuilder.Entity<State>(entity =>
        {
            entity.HasKey(e => e.StateCode);

            entity.Property(e => e.StateCode)
                .HasMaxLength(2)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.StateName)
                .HasMaxLength(20)
                .IsUnicode(false);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}