﻿namespace MMAProducts
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            txtProductCode = new TextBox();
            lblDesc = new Label();
            lblUnitPrice = new Label();
            lblOnHand = new Label();
            btnGetProduct = new Button();
            btnAdd = new Button();
            btnExit = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(71, 59);
            label1.Name = "label1";
            label1.Size = new Size(164, 32);
            label1.TabIndex = 0;
            label1.Text = "Product Code:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(95, 127);
            label2.Name = "label2";
            label2.Size = new Size(140, 32);
            label2.TabIndex = 1;
            label2.Text = "Description:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(114, 194);
            label3.Name = "label3";
            label3.Size = new Size(121, 32);
            label3.TabIndex = 2;
            label3.Text = "Unit Price:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(25, 268);
            label4.Name = "label4";
            label4.Size = new Size(210, 32);
            label4.TabIndex = 3;
            label4.Text = "Quantity on Hand:";
            // 
            // txtProductCode
            // 
            txtProductCode.Location = new Point(255, 56);
            txtProductCode.Name = "txtProductCode";
            txtProductCode.Size = new Size(200, 39);
            txtProductCode.TabIndex = 4;
            // 
            // lblDesc
            // 
            lblDesc.BorderStyle = BorderStyle.Fixed3D;
            lblDesc.Location = new Point(255, 127);
            lblDesc.Name = "lblDesc";
            lblDesc.Size = new Size(683, 32);
            lblDesc.TabIndex = 5;
            // 
            // lblUnitPrice
            // 
            lblUnitPrice.BorderStyle = BorderStyle.Fixed3D;
            lblUnitPrice.Location = new Point(255, 194);
            lblUnitPrice.Name = "lblUnitPrice";
            lblUnitPrice.Size = new Size(283, 32);
            lblUnitPrice.TabIndex = 6;
            // 
            // lblOnHand
            // 
            lblOnHand.BorderStyle = BorderStyle.Fixed3D;
            lblOnHand.Location = new Point(255, 268);
            lblOnHand.Name = "lblOnHand";
            lblOnHand.Size = new Size(283, 32);
            lblOnHand.TabIndex = 7;
            // 
            // btnGetProduct
            // 
            btnGetProduct.Location = new Point(543, 52);
            btnGetProduct.Name = "btnGetProduct";
            btnGetProduct.Size = new Size(150, 46);
            btnGetProduct.TabIndex = 8;
            btnGetProduct.Text = "Get Product";
            btnGetProduct.UseVisualStyleBackColor = true;
            btnGetProduct.Click += btnGetProduct_Click;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(164, 363);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(184, 117);
            btnAdd.TabIndex = 9;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnExit
            // 
            btnExit.Location = new Point(525, 363);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(184, 117);
            btnExit.TabIndex = 10;
            btnExit.Text = "Exit";
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += btnExit_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(976, 571);
            Controls.Add(btnExit);
            Controls.Add(btnAdd);
            Controls.Add(btnGetProduct);
            Controls.Add(lblOnHand);
            Controls.Add(lblUnitPrice);
            Controls.Add(lblDesc);
            Controls.Add(txtProductCode);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Product Maintenance";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox txtProductCode;
        private Label lblDesc;
        private Label lblUnitPrice;
        private Label lblOnHand;
        private Button btnGetProduct;
        private Button btnAdd;
        private Button btnExit;
    }
}
